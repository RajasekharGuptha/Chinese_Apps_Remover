package com.rahtech.chineseappsremover;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    PackageManager packageManager;
    ArrayList<String> appsArrayList;
    private ListView app_names;
    int pos;
    private Map<String,String[]> chinese_alternatives;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chinese_alternatives =new HashMap();
        app_names= findViewById(R.id.app_names_list);
        appsArrayList=new ArrayList<String>();
        chinese_alternatives.put("app.buzz.share",new String[]{"com.roposo.android"});
        chinese_alternatives.put("app.buzz.share.lite",new String[]{"com.roposo.android"});
        chinese_alternatives.put("com.lenovo.anyshare.gps",new String[]{"com.google.android.apps.nbu.files"});
        chinese_alternatives.put("cn.xender",new String[]{"com.google.android.apps.nbu.files"});
        chinese_alternatives.put("com.intsig.camscanner",new String[]{"com.adobe.scan.android","net.doc.scanner"});
        chinese_alternatives.put("com.intsig.camscannerhd",new String[]{"com.adobe.scan.android","net.doc.scanner"});
        chinese_alternatives.put("com.intsig.lic.camscanner",new String[]{"com.adobe.scan.android","net.doc.scanner"});
        chinese_alternatives.put("com.tencent.ig",new String[]{"com.activision.callofduty.shooter"});
        chinese_alternatives.put("com.tencent.iglite",new String[]{"com.activision.callofduty.shooter"});
        chinese_alternatives.put("com.domobile.applockwatcher",new String[]{"com.symantec.applock"});
        chinese_alternatives.put("com.domobile.applock.lite",new String[]{"com.symantec.applock"});
        chinese_alternatives.put("com.truecaller",new String[]{"gogolook.callgogolook2"});
        chinese_alternatives.put("com.uc.vmate",new String[]{"com.roposo.android"});
        chinese_alternatives.put("club.fromfactory",new String[]{"in.amazon.mShop.android.shopping","com.flipkart.android"});
        chinese_alternatives.put("com.zzkko",new String[]{"in.amazon.mShop.android.shopping","com.flipkart.android","com.ril.ajio"});
        chinese_alternatives.put("com.romwe",new String[]{"in.amazon.mShop.android.shopping","com.flipkart.android","com.ril.ajio"});
        //uc
        chinese_alternatives.put("com.UCMobile.intl",new String[]{"com.brave.browser"});
        chinese_alternatives.put("com.uc.browser.en",new String[]{"com.brave.browser"});
        chinese_alternatives.put("com.ucturbo",new String[]{"com.brave.browser"});
        //cricket
        chinese_alternatives.put("com.CricChat.intl",new String[]{"com.cricbuzz.android"});
        //alt not found
        chinese_alternatives.put("com.uc.iflow",new String[]{"com.cricbuzz.android"});
        chinese_alternatives.put("com.zhiliaoapp.musically",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("com.zhiliao.musically.livewallpaper",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("video.like",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("com.kwai.video",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("sg.bigo.live",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("com.commsource.beautyplus",new String[]{"com.ss.android.ugc.boom"});
        chinese_alternatives.put("com.hcg.cok.gp",new String[]{"com.supercell.clashofclans"});
        chinese_alternatives.put("com.hcg.ctw.gp",new String[]{"com.supercell.clashofclans"});
        chinese_alternatives.put("com.dc.hwsj",new String[]{"com.supercell.clashofclans"});
        chinese_alternatives.put("com.elex.coq.gp",new String[]{"com.supercell.clashofclans"});
        chinese_alternatives.put("com.mobile.legends",new String[]{"com.activision.callofduty.shooter"});
        chinese_alternatives.put("com.yottagames.mafiawar",new String[]{"com.activision.callofduty.shooter","com.fungames.sniper3d"});
        chinese_alternatives.put("com.moonton.mobilehero",new String[]{"com.activision.callofduty.shooter"});
        chinese_alternatives.put("com.weico.international",new String[]{"com.facebook.katana","com.facebook.lite","com.whatsapp"});
        chinese_alternatives.put("com.tencent.mm",new String[]{"com.facebook.katana","com.facebook.lite","com.whatsapp"});
        chinese_alternatives.put("cn.wps.moffice_eng",new String[]{"com.infraware.office.link","com.infraware.office.reader.team"});
        chinese_alternatives.put("cn.wps.pdf",new String[]{"com.infraware.office.link","com.infraware.office.reader.team"});
        chinese_alternatives.put("cn.wps.moffice_i18n",new String[]{"com.infraware.office.link","com.infraware.office.reader.team"});
        chinese_alternatives.put("us.zoom.videomeetings",new String[]{"com.google.android.apps.meetings","com.jiochat.jiochatapp","com.facebook.orca"});
        packageManager=getPackageManager();
        final List<PackageInfo> packageInfoList = packageManager.getInstalledPackages(PackageManager.GET_SIGNATURES);
        if(packageInfoList!=null)
        {
            for(PackageInfo packageInfo : packageInfoList) {
                ApplicationInfo applicationInfo;
                applicationInfo = packageInfo.applicationInfo;
                if ((applicationInfo.flags & 1) == 0) {
                    if(chinese_alternatives.containsKey(packageInfo.packageName))
                        appsArrayList.add(applicationInfo.packageName);
                }
            }

        }
        else
        {
            Toast.makeText(this, "No Applications Installed..!!", Toast.LENGTH_SHORT).show();
        }
        Collections.sort(appsArrayList,new sortComp());
        Log.i("Sizeee",String.valueOf(appsArrayList.size()));
        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_multiple_choice,appsArrayList);
        app_names.setAdapter(adapter);

        app_names.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pos=position;
                Intent intent = new Intent(Intent.ACTION_DELETE);
                intent.setData(Uri.parse("package:"+appsArrayList.get(pos)));
                startActivityForResult(intent,1);
            }
        });


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Intent i=new Intent(MainActivity.this,suggestions.class);
                i.putExtra("suggs",chinese_alternatives.get(appsArrayList.get(pos)));
                startActivity(i);
            } else if (resultCode == RESULT_CANCELED) {
                Log.d("TAG", "Cancelled");
            } else if (resultCode == RESULT_FIRST_USER) {
                Log.d("TAG", "Failed!Try again..!");
            }
        }
    }

    public class sortComp implements Comparator<String> {

        @Override
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    }

}
