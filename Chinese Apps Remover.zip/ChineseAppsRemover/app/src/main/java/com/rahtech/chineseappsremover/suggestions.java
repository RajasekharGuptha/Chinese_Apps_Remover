package com.rahtech.chineseappsremover;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class suggestions extends AppCompatActivity {

    ListView listView;
    String[] suggestions_list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestions);
        listView=findViewById(R.id.suggestions);

        suggestions_list=getIntent().getStringArrayExtra("suggs");
        ArrayAdapter arrayadapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,suggestions_list);
        listView.setAdapter(arrayadapter);

    }
}
